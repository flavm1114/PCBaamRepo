﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace PCBaam.Data
{
    class CustomerData : EntityData<CustomerData>
    {
//        public List<Customer> Compare(string customerId, string Pw)
//        {
////            PC_Cafe_OrderEntities context = new PC_Cafe_OrderEntities();
////            context.Database.Log = log => Console.WriteLine(log);
////
////            var query = from x in context.Customers;
//
//
//        }
    }
}
